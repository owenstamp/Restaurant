﻿namespace Restaurant.Data;

public class Class1
{

}

﻿namespace Restaurant.Domain;

public class Class1
{

}

using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Http;
using Restaurant.Data;
using Restaurant.Domain.Entities;
using System.Linq;

public class LoginModel : PageModel
{
    private readonly AppDbContext _context;

    public LoginModel(AppDbContext context)
    {
        _context = context;
    }

    [BindProperty]
    public string Username { get; set; }

    [BindProperty]
    public string Password { get; set; }

    public bool LoginFailed { get; set; }

    public void OnGet()
    {
        // Optional: clear session on visiting login
        HttpContext.Session.Clear();
    }

    public IActionResult OnPost()
    {
        // Simple lookup from UserAccounts table
        var account = _context.UserAccounts
            .FirstOrDefault(u => u.Username == Username && u.Password == Password); // TODO: hash password

        if (account != null)
        {
            // Get related staff (optional, if role is there)
            var staff = _context.Staff.FirstOrDefault(s => s.Id == account.StaffId);

            var role = staff?.Role ?? "User";

            // Set session values
            HttpContext.Session.SetString("Username", Username);
            HttpContext.Session.SetString("UserRole", role);

            return RedirectToPage("/Index");
        }

        LoginFailed = true;
        return Page();
    }
}
